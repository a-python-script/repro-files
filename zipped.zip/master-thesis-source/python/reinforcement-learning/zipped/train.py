from model import PPOModel
import ray
from ray.rllib.models import ModelCatalog
from ray import tune
import os
import time
import shutil
import argparse
import pickle

# =========================================================================== #
#                                                                             #
# CUDA ausschalten
#                                                                             #
# =========================================================================== #
print(__debug__)
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# =========================================================================== #
#                                                                             #
# Kommandozeilenargumente
#                                                                             #
# =========================================================================== #
parser = argparse.ArgumentParser()

parser.add_argument(
    "--bundle_file",
    default="bundle0.pkl",
    type=str,
    help="Bundle of configs for ray.tune to start training with"
)
parser.add_argument(
    "--meta_file",
    default="meta.pkl",
    type=str,
    help="Meta information file"
)
parser.add_argument(
    "--output_folder",
    default="/home/lukas/master-thesis-source/python/results/local",
    type=str,
    help="Output folder for the ray results"
    )
args = parser.parse_args()

assert os.path.exists(args.meta_file), f"File does not exist {args.meta_file}"
assert os.path.exists(args.bundle_file), \
    f"File does not exist {args.bundle_file}"

# =========================================================================== #
#                                                                             #
# Bestehenden Ausgabeordner löschen/frisch erstellen
#                                                                             #
# =========================================================================== #
if os.path.exists(args.output_folder):
    print(f"*Deleting {args.output_folder}")
    shutil.rmtree(args.output_folder)
print(f"*Creating {args.output_folder}")
os.makedirs(args.output_folder) 

# =========================================================================== #
#                                                                             #
# Ray initialisieren
#                                                                             #
# =========================================================================== #
if ray.is_initialized():
    ray.shutdown()
ray.init()
time.sleep(10.0) # Warte 10 Sekunden bis Worker fertig sind
print(ray.available_resources())
print(f"ray.__version__=={ray.__version__}")

# =========================================================================== #
#                                                                             #
# Eigenes Modell registrieren
#                                                                             #
# =========================================================================== #
# TO DO: Das hier für R2D2 anpassen. Soll beides gehen !!!
# Über meta-Datei konfigurieren !!!!
ModelCatalog.register_custom_model("MarketModel", PPOModel)


# =========================================================================== #
#                                                                             #
# Bundles lesen + Tune Konfiguration erstellen
#                                                                             #
# =========================================================================== #
configs = pickle.load(open(args.bundle_file, "rb"))
meta = pickle.load(open(args.meta_file, "rb"))
num_train_iter_per_epoch = meta["num_train_iter_per_epoch"]

        
# =========================================================================== #
#                                                                             #
# Training starten
#                                                                             #
# =========================================================================== #
EPOCHS = 250

# Kein Tensorboard- und CSV-Logging
os.environ["TUNE_DISABLE_AUTO_CALLBACK_LOGGERS"] = "1"

# Tune starten
print("Start training")
tune.run(
    "PPO",
    config=tune.grid_search(configs),
    verbose=1, # 1 = only status
    num_samples=1, # wird über "seeds" gesteuert
    checkpoint_freq=0, # Keine Checkpoints
    checkpoint_at_end=False, # Am Ende nie Checkpoint
    local_dir=args.output_folder,
    callbacks=[
        #CustomResultsCallback(), # WIEDER REINNEHMEN !!!
        tune.logger.JsonLoggerCallback(),
        tune.logger.CSVLoggerCallback()
    ],
    raise_on_failed_trial=False, # Keine Exception sonst startet Kubernetes
                                 # Diesen Pod neu.
    max_failures=0, # Kein Neuversuch, falls ein Trial fehlschlägt
    max_concurrent_trials=0,

    # To Do: Wie muss man das für R2D2 ändern??
    stop=tune.stopper.MaximumIterationStopper(EPOCHS * num_train_iter_per_epoch)
)

