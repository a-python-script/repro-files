from ray.rllib.utils.annotations import override
from ray.rllib.models.torch.recurrent_net import RecurrentNetwork
from ray.rllib.models.modelv2 import ModelV2
import torch.nn as nn
import torch
from ray.rllib.models.torch.torch_modelv2 import TorchModelV2


from time2vec import Time2Vec

class PPOModel(RecurrentNetwork, nn.Module):
    def __init__(self, 
                 obs_space, 
                 action_space, 
                 num_outputs,
                 model_config, 
                 name):
        nn.Module.__init__(self)
        super().__init__(obs_space, 
                         action_space, 
                         num_outputs, 
                         model_config, 
                         name)
        
        # Netzwerk-Aufbau
        # Input Layer
        # First Hidden Layer
        # GELU
        # Dropout
        # Second Hidden Layer
        # GELU
        # Dropout
        # LSTM
        # Dropout
        #   Value (1)
        #   Policy(num_outputs) 

        # Modellkonfiguration einlesen
        _model = model_config["custom_model_config"]["model"]
        self.first_hidden_size = _model["first_hidden_size"]
        self.second_hidden_size = _model["second_hidden_size"]
        self.lstm_hidden_size = _model["lstm_hidden_size"]
        self.dropout_p = _model["dropout_p"]
        
        # Konfiguration für Time2Vec
        _time2vec = model_config["custom_model_config"]["time2vec"]
        self.use_time2vec = _time2vec["use_time2vec"]
        self.k = _time2vec["k"]
        
        # Netzwerk definieren
        self.gelu = nn.GELU()
        self.time2vec = Time2Vec(self.k)
        in_features = obs_space.shape[0] if not self.use_time2vec else \
            obs_space.shape[0] + self.k
        self.lin1 = nn.Linear(#in_features=obs_space.shape[0],
            in_features=in_features,
            out_features=self.first_hidden_size,
            bias=True
        )
        self.lin2 = nn.Linear(
            in_features=self.first_hidden_size,
            out_features=self.second_hidden_size,
            bias=True
        )
        self.lstm = nn.LSTM(
            input_size=self.second_hidden_size,
            hidden_size=self.lstm_hidden_size,
            num_layers=1,
            bias=True,
            batch_first=True,
            dropout=0.0,
            bidirectional=False,
            proj_size=0
        )
        self.dropout = nn.Dropout(p=self.dropout_p)
        self.vf = nn.Linear(
            in_features=self.lstm_hidden_size,
            out_features=1,
            bias=True
        )
        self.pi = nn.Linear(
            in_features=self.lstm_hidden_size,
            out_features=num_outputs,
            bias=True
        )
        self.value = None

        # Debug: Prüfe die Initialisierung
        for name, param in self.named_parameters():
            if not torch.isfinite(param).all().item():
                raise Exception(f"{name} is not finite after initialization")

    @override(ModelV2)
    def get_initial_state(self):
        h0, c0 = torch.zeros(self.lstm_hidden_size), \
            torch.zeros(self.lstm_hidden_size)
        return [h0, c0]
     
    @override(RecurrentNetwork)
    def forward_rnn(self, inputs, state, seq_lens):
        assert not inputs.isnan().any(), "NaN in inputs in forward"
        h0 = torch.unsqueeze(state[0], 0)
        c0 = torch.unsqueeze(state[1], 0)
        
        # Time2Vec
        if self.use_time2vec:
            
            # Der Zeitstempel steckt immer im letzten Feature
            times = inputs[:,:,-1].unsqueeze(2)
            t2v = self.time2vec(times)
            inp = torch.cat((inputs[:,:,0:-1], t2v), dim=2)

        # Wenn kein Time2Vec verwendet wird, dann beinhalten die Inputs hier
        # auch keine Time2Vec-Zeitstempel (das ist bei der Trendvorhersage
        # anders)
        else:
            inp = inputs
        
        gelu1 = self.dropout(self.gelu(self.lin1(inp)))
        gelu2 = self.dropout(self.gelu(self.lin2(gelu1)))

        output, (h_n, c_n) = self.lstm(gelu2, (h0, c0))
        output = self.dropout(output) # Dropout

        logits = self.pi(output)
        self.value = self.vf(output).flatten()

        # Prüfe zunächst einmal die logits
        if not torch.isfinite(logits).all().item():
            print(f"logits are not finite:\n{logits}")

        return logits, [torch.squeeze(h_n, 0), torch.squeeze(c_n, 0)]
    
    @override(ModelV2)    
    def value_function(self):
        return self.value





    
    