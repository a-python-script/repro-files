import torch.nn as nn
import torch


class Time2Vec(nn.Module):
    def __init__(self, k: int = 32):
        super(Time2Vec, self).__init__()
        self.k = k
        
        # Gewichte initialisieren 
        self.omega0 = nn.Parameter(torch.rand(1))
        self.omega = nn.Parameter(torch.rand(k))
        self.phi0 = nn.Parameter(torch.rand(1))
        self.phi = nn.Parameter(torch.rand(k))
        
        # Sinus als periodische Aktivierungsfunktion (Paper Seite 3)
        self.sin = torch.sin
        
    # Forward-Pass, geprüft, ist OK !!
    def forward(self, x: torch.Tensor) -> torch.Tensor: 
        v0 = self.omega0 * x + self.phi0
        v1 = self.sin(self.omega * x + self.phi)
        return torch.cat((v0, v1), 2) # Konkatenierung geprüft, ist OK !!
 

    
# Test
"""
taus = torch.tensor([[[1], [2], [3], [4], [5]],
                     [[6], [7], [8], [9], [10]],
                     [[4], [5], [6], [7], [8]]]).float()

#taus = torch.tensor([100345, 100445, 200434, 200668, 340003]).float()
t2v = Time2Vec(16)
t2v(taus)
#t2v(torch.tensor([123]).float())
"""
